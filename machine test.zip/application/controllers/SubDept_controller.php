<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class SubDept_controller extends CI_Controller 
{



		
	

}