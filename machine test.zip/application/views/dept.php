
	<div class="container-fluid">
		<div class = "login_header">
			
			<h3 class = "login_heading" ><u>Edit</u> <u>Details</u></h3>
			
			<!-- Basic Details -->


			<br>
	
	<!-- <form method="post" action="<?php echo base_url(); ?>dept_controller/upload_profile" enctype="multipart/form-data" > -->

		<?php echo form_open_multipart('dept_controller/upload_profile');?>

			
			<input type="hidden" name="user_email" value="<?php echo $_SESSION['user_email']?> ">

			
		
			<label class = "l1">Profile Avater : </label> &nbsp;

			
			<input type="file" name="file"  class = "t1 read"><br><br>

			<label class = "l1" >Select Department :  &nbsp;
			<select style="margin-left:31px;" id = 'dept' name="dept">
				<option>Select</option>
				<?php

				foreach ($user_dept as $key => $value) {
				?>
				<option value="<?php echo $value['dept'];?>" ><?php echo $value['dept'];?></option>
				

				<?php

			}

			?>
			</select>
		</label>
		
			</div>
			<br>


			<label class = "l1">Enter Sub-Department :  &nbsp;
			<select id = "subdept" name="subdept">
				<option value="">Select Sub Dept</option>
				<option value="Backend Developer">Backend Developer</option>
				<option value="Frontend Developer">Frontend Developer</option>
				<option value="Business Analyst">Business Analyst</option>
				<option value="Business Devlopment Exec">Business Devlopment Exec.</option>
				<option value="Finanical Analyst">Finanical Analyst</option>
				<option value="Chartred Accoutant">Chartred Accoutant</option>
			</select></label>
			<br><br>

			<input type = "submit" class = "btn btn-primary" value = "Save">

		
		</form>
		</div>

		<script type="text/javascript">
				
				<?php
					if(isset($_SESSION['inserted'] ))
					{
						echo "alert('data updated!!!') ";
					}
			
			?>
		</script>