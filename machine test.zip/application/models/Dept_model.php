<?php

class Dept_model extends CI_Model
{
	
	function return_dept()
	{
		$this->load->database();
		$query = $this->db->query("select * from cl_3");
		$query->result_array();
			
		return $query->result_array();
	}

	
}