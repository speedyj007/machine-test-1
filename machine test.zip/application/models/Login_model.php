<?php

class Login_model extends CI_Model
{
	
	function return_data()
	{

		

		
	}
}