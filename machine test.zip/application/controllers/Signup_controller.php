<?php

// defined('BASEPATH') OR exit('No direct script access allowed');

class Signup_controller extends CI_Controller 
{


public function index()

	{

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->load->model('signup_model');
		

		$this->form_validation->set_rules("fname", "fname", "required|trim|alpha");
		$this->form_validation->set_rules("lname", "lname", "required|trim|alpha");
		$this->form_validation->set_rules("email", "email", "required|trim|valid_email");
		$this->form_validation->set_rules("password", "password", "required|trim|alpha_numeric");

		if ($this->form_validation->run() == FALSE)
        
             {

                $this->load->view('sign_up');
             }
        else{

        	$key = md5(rand());
        	$encrpt = $this->encrypt->encode($this->input->post('password'));

        	$data = array(
        		'fname' => $this->input->post('fname'),
        		'lname' => $this->input->post('lname'),
        		'email' => $this->input->post('email'),
        		'password' => $encrpt
        		
        		
        	);

        	$id = $this->signup_model->insert($data);

        	if($id > 0)
        	{

        		$query = $this->db->query("select * from cl_1 where email = '$email' ");

        		if($query->num_rows())
           		{
           			
           			$result = $query->result_array();

           			
           			$this->session->set_userdata('user_id', $result[0]['id']);

           		}

           		session_destroy();
        		redirect('login_controller/index');


        	}

        }     

	}

  function log_out()
  {
    session_destroy();
    redirect('login_controller/index');
  }

}

