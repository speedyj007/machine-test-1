<?php



class Dashboard_controller extends CI_Controller 
{
	public function index()

	{
		if(isset($_SESSION['user_id']) && isset($_SESSION['user_email']))

		{	
			$this->load->helper('form');
			$id = $_SESSION['user_id'];
			$email = $_SESSION['user_email'];


			$this->load->view("header");

			$this->load->model('dept_model');
			$user_dept["user_dept"] = $this->dept_model->return_dept();
			$this->load->view("dept", $user_dept); 

			$this->load->model('profile_model');
			$user_array["user_data"] = $this->profile_model->return_profile();
			$this->load->view("dashboard", $user_array); 			

			
			}
	else{
		redirect('login_controller/index');
	}

	}

	

	function log_out()
	{
		session_destroy();
		redirect('login_controller/index');
	}


}