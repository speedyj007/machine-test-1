<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login_controller extends CI_Controller 
{
	public function index()

	{
		 $this->load->library('form_validation');
		 $this->load->helper('form');

		 $this->form_validation->set_rules("email", "Email id", "required|valid_email");
		 

		 if ($this->form_validation->run() == FALSE)
             {

                $this->load->view('email_check');
             }

           else{
           		
           		if(isset($_POST))
           		{
           		
           		$email = $_POST['email'];

           		
           		
           		$query = $this->db->query("select * from cl_1 where email = '$email' ");

           		if($query->num_rows())
           		{
           			
           			$result = $query->result_array();

           			
           			$this->session->set_userdata('user_id', $result[0]['id']);
                $this->session->set_userdata('user_email', $result[0]['email']);
           			$this->session->set_userdata('user_pass', $result[0]['password']);

           			redirect('pass_controller/index');

           		}
           		else{
  
                

					   $this->load->view('sign_up');
           		}


           		}

           		else{	
           			$this->load->view('sign_up');
           		}
           		

           } 

            
	}

	
}