-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql313.byetcluster.com
-- Generation Time: Apr 12, 2021 at 09:53 PM
-- Server version: 5.6.48-88.0
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_24462442_stf`
--

-- --------------------------------------------------------

--
-- Table structure for table `cl_1`
--

CREATE TABLE `cl_1` (
  `id` int(100) UNSIGNED NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `profile_pic` varchar(250) DEFAULT NULL,
  `dept` varchar(250) DEFAULT NULL,
  `subdept` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cl_1`
--

INSERT INTO `cl_1` (`id`, `fname`, `lname`, `email`, `password`, `profile_pic`, `dept`, `subdept`) VALUES
(1, 'Meria', 'Roy', 'meria1440@gmail.com', 'AjQBYldtVmVVMQcxADYDPg==', 'uploads/Hydrangeas.jpg', 'Technology', 'Backend Developer'),
(9, 'Rahul', 'yadav', 'rahul14@gmail.com', 'BjALaFRuUWIPa1JkCD4BPA==', 'uploads/Penguins.jpg', 'Marketing', 'Frontend Developer'),
(11, 'Pinky', 'sen', 'pinky1440@gmail.com', 'ATcBYgU/BDcCZldhADZTbg==', NULL, NULL, NULL),
(12, 'John', 'More', 'john1440@gmail.com', 'BzFTMFNpUmEBZQI0BDJTbg==', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cl_3`
--

CREATE TABLE `cl_3` (
  `dept_id` int(100) UNSIGNED NOT NULL,
  `dept` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cl_3`
--

INSERT INTO `cl_3` (`dept_id`, `dept`) VALUES
(1, 'Technology'),
(2, 'Marketing'),
(3, 'Accounts');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cl_1`
--
ALTER TABLE `cl_1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cl_3`
--
ALTER TABLE `cl_3`
  ADD PRIMARY KEY (`dept_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cl_1`
--
ALTER TABLE `cl_1`
  MODIFY `id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cl_3`
--
ALTER TABLE `cl_3`
  MODIFY `dept_id` int(100) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
