<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pass_controller extends CI_Controller 
{


public function index()

	{
		
		if(isset($_SESSION['user_id']) && isset($_SESSION['user_pass']) &&  isset($_SESSION['user_email']))

		{

			$id = $_SESSION['user_id'];
			$email = $_SESSION['user_email'];

			$this->load->library('form_validation');
			$this->load->helper('form');

		 $this->form_validation->set_rules("password", "Password", "required|alpha_numeric");
		 

		 if ($this->form_validation->run() == FALSE)
             {

                $this->load->view('pass_check');
             }

           else{
           		
           		if(isset($_POST))
           		{
           		
           		$password = $_POST['password'];

           		$id = $_SESSION['user_id'];
           		$pass = $_SESSION['user_pass'];

         		$encrpt = $this->encrypt->decode($pass);
           		

           		if($encrpt == $password)
           		{
           			
           			redirect('dashboard_controller/index');

           		}

           		else{
					$this->load->view('sign_up');
           		}

           	}

		}
	}

		else{

			redirect('login_controller/index');
		}
		   
	

}
	function log_out()
	{
		session_destroy();
		redirect('login_controller/index');

	}

}