<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

	<div class = "container-fluid">

			<hr class = "hr2">



			<!-- Profile Information -->

			<h3 class = "login_heading" ><u>Profile</u> <u>Information</u></h3>

			<div class = "login_form"  >

			<label class = "l1">Profile Pic : </label> &nbsp; 
			<img src="<?php echo base_url().$user_data[0]['profile_pic']; ?>" style ="width: 8%;
    		border-radius: 11px 50%;">
			<br><br>
			
			<label class = "l1">Department : </label> &nbsp; 
			<input type = "text" class = "t1 read" placeholder ="" name = "fname" value="<?php echo 
			$user_data[0]['dept']; ?> "  readonly><br><br>

			<label class = "l1">Sub-Department : </label> &nbsp; 
			<input type = "text" class = "t1 read" placeholder ="" name = "fname" value="<?php echo 
			$user_data[0]['subdept']; ?> "  readonly><br><br>
			
			<label class = "l1">First Name : </label> &nbsp; 
			<input type = "text" class = "t1 read" placeholder ="" name = "fname" value="<?php echo 
			$user_data[0]['fname']; ?> "  readonly><br><br>

			<label class = "l1">Last Name : </label> &nbsp;
			<input type = "text" class = "t1 read" placeholder ="" name = "lname" autocomplete = "off"  value="<?php echo $user_data[0]['lname']; ?>" readonly><br><br>

			<label class = "l1">Email Id : </label> &nbsp;
			<input type = "email" class = "t1 read" placeholder ="" name = "email" autocomplete = "off" value="<?php echo $user_data[0]['email']; ?>" readonly><br><br>
			
		
			

			</div>	
	</div>


 </body>
 </html>			