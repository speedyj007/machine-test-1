<?php

class Signup_model extends CI_Model
{
	
	function insert($data)
	{

		$this->db->insert('cl_1',$data);
		return $this->db->insert_id();

		
	}
}