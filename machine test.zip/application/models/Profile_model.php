<?php

class Profile_model extends CI_Model
{
	
	function return_profile()
	{
		if(isset($_SESSION['user_id']))

		{
		
		$id = $_SESSION['user_id'];

		$this->load->database();
		$query = $this->db->query("select * from cl_1 where id = '$id' ");
		$query->result_array();
			
		return $query->result_array();

	}
	}

}